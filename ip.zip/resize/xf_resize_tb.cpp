/***************************************************************************
Copyright (c) 2018, Xilinx, Inc.
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice,
this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
may be used to endorse or promote products derived from this software
without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

***************************************************************************/


#include <iostream>
#include "xf_headers.h"
#include "xf_resize_config.h"

int main(int argc, char** argv)
{

	if(argc != 2)
	{
		fprintf(stderr,"Invalid Number of Arguments!\nUsage:\n");
		fprintf(stderr,"<Executable Name> <input image path> \n");
		return -1;
	}

	cv::Mat in_img, out_hls, out_ocv, out_err;

	// reading in the color image
	in_img = cv::imread(argv[1], 1);
	if (in_img.data == NULL)
	{
		fprintf(stderr,"Cannot open image at %s\n", argv[1]);
		return 0;
	}

	uint16_t src_height = in_img.rows;
	uint16_t src_width = in_img.cols;
	uint16_t dst_height = src_height/2;
	uint16_t dst_width = src_width/2;
	std::cout << "src_height " << src_height << " src_width " << src_width << " dst_height " << dst_height << " dst_width " << dst_width;
	std::cout << std::endl;
	// create memory for output images
	out_hls.create(dst_height,dst_width,in_img.type());
	out_ocv.create(dst_height,dst_width,in_img.type());
	out_err.create(dst_height,dst_width,in_img.type());

	hls::stream< ap_axiu<32,1,1,1> > _src,_dst;

	cvMat2AXIvideoxf<NPC1>(in_img, _src);

	resize_ip(_src, _dst,src_height,src_width, dst_height, dst_width);

	AXIvideo2cvMatxf<NPC1>(_dst, out_hls);

	cv::imwrite("out_hls.jpg", out_hls);

	///////////////// 	Opencv  Reference  ////////////////////////
	cv::resize(in_img,out_ocv,cv::Size(dst_width, dst_height),0,0,CV_INTER_LINEAR);
	cv::imwrite("out_ocv.jpg", out_ocv);

	//////////////////  Compute Absolute Difference ////////////////////
	cv::absdiff(out_ocv, out_hls, out_err);
	cv::imwrite("out_err.jpg", out_err);

	// Find minimum and maximum differences.
	double minval=256,maxval=0;
	int cnt = 0;
	for (int i=0;i<out_err.rows;i++){
		for(int j=0;j<out_err.cols;j++){
			uchar v = out_err.at<uchar>(i,j);
			if (v>1)
				cnt++;
			if (minval > v )
				minval = v;
			if (maxval < v)
				maxval = v;
		}
	}
	float err_per = 100.0*(float)cnt/(out_err.rows*out_err.cols);

	fprintf(stderr,"Minimum error in intensity = %f\n Maximum error in intensity = %f\n Percentage of pixels above error threshold = %f\n",minval,maxval,err_per);

	if(maxval>2){
		printf("\nTest Failed\n");
		return -1;
	}

	return 0;

}
