#include "xf_resize_config.h"

void resize_accel(xf::Mat<TYPE, HEIGHT, WIDTH, NPC1> &_src, xf::Mat<TYPE, HEIGHT, WIDTH, NPC1> &_dst);
void resize_ip(hls::stream< ap_axiu<32,1,1,1> >& _src,hls::stream< ap_axiu<32,1,1,1> >& _dst,int src_height,int src_width, int dst_height, int dst_width)
{
#pragma HLS INTERFACE axis register both  port=_src
#pragma HLS INTERFACE axis register both  port=_dst
#pragma HLS INTERFACE s_axilite port=src_height
#pragma HLS INTERFACE s_axilite port=src_width
#pragma HLS INTERFACE s_axilite port=dst_height
#pragma HLS INTERFACE s_axilite port=dst_width
#pragma HLS INTERFACE s_axilite port=return

	 xf::Mat<TYPE, HEIGHT, WIDTH, NPC1> imgInput1(src_height,src_width);
	 xf::Mat<TYPE, HEIGHT, WIDTH, NPC1> imgOutput1(dst_height,dst_width);

#pragma HLS stream variable=imgInput1.data dim=1 depth=1
#pragma HLS stream variable=imgOutput1.data dim=1 depth=1
#pragma HLS dataflow

	xf::AXIvideo2xfMat(_src, imgInput1);

	resize_accel(imgInput1,imgOutput1);

	xf::xfMat2AXIvideo(imgOutput1, _dst);

}
