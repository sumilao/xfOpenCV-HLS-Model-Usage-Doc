/*  set the optimization type  */
#define NO  	1 			// Normal
#define RO  	0 			// Resource Optimized

#define NMS 1

#define WIDTH 	1920
#define HEIGHT	1080


#define MAXCORNERS  1024
